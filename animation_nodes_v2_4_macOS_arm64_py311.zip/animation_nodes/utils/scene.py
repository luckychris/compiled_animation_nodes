def getFPS(scene):
    return scene.render.fps / scene.render.fps_base
