import bpy
from bpy.props import *
from ... base_types import AnimationNode, VectorizedSocket
from ... data_structures.splines.to_blender import setSplinesOnBlenderObject

class CurveObjectOutputNode(AnimationNode, bpy.types.Node):
    bl_idname = "an_CurveObjectOutputNode"
    bl_label = "Curve Object Output"
    bl_width_default = 180
    errorHandlingType = "MESSAGE"

    useSplineList: VectorizedSocket.newProperty()

    def create(self):
        socket = self.newInput("Object", "Object", "object")
        socket.defaultDrawType = "PROPERTY_ONLY"
        socket.objectCreationType = "CURVE"

        self.newInput(VectorizedSocket("Spline", "useSplineList",
            ("Spline", "spline", dict(defaultDrawType = "TEXT_ONLY")),
            ("Splines", "splines", dict(defaultDrawType = "TEXT_ONLY"))))

        self.newInput("Float", "Bevel Depth", "bevelDepth", minValue = 0)
        self.newInput("Integer", "Bevel Resolution", "bevelResolution")
        self.newInput("Float", "Extrude", "extrude")
        self.newInput("Float", "Bevel Start", "bevelStart")
        self.newInput("Float", "Bevel End", "bevelEnd", value = 1.0)
        self.newInput("Float", "Offset", "offset")
        self.newInput("Integer", "Preview Resolution", "previewResolution", value = 12)
        self.newInput("Object", "Taper Object", "taperObject")
        self.newInput("Text", "Taper Mode", "taperMode", value = "MULTIPLY")
        self.newInput("Object", "Bevel Object", "bevelObject")
        self.newInput("Boolean", "Fill Caps", "fillCaps")
        self.newInput("Text", "Fill Mode", "fillMode", value = "FRONT")
        self.newInput("Text", "Bevel Mode", "bevelMode", value = "ROUND")

        self.newOutput("Object", "Object", "object")

        for socket in self.inputs[1:]:
            socket.useIsUsedProperty = True
            socket.isUsed = False
        for socket in self.inputs[4:]:
            socket.hide = True

    def getExecutionCode(self, required):
        yield "if getattr(object, 'type', '') == 'CURVE':"
        yield "    curve = object.data"

        s = self.inputs
        if self.useSplineList:
            if s["Splines"].isUsed:         yield "    self.setSplines(object, splines)"
        else:
            if s["Spline"].isUsed:          yield "    self.setSplines(object, [spline])"
        if s["Bevel Depth"].isUsed:         yield "    curve.bevel_depth = bevelDepth"
        if s["Bevel Resolution"].isUsed:    yield "    curve.bevel_resolution = bevelResolution"
        if s["Bevel Start"].isUsed:         yield "    curve.bevel_factor_start = bevelStart"
        if s["Bevel End"].isUsed:           yield "    curve.bevel_factor_end = bevelEnd"
        if s["Extrude"].isUsed:             yield "    curve.extrude = extrude"
        if s["Offset"].isUsed:              yield "    curve.offset = offset"
        if s["Preview Resolution"].isUsed:  yield "    curve.resolution_u = previewResolution"
        if s["Taper Object"].isUsed:        yield "    curve.taper_object = taperObject"
        if s["Taper Mode"].isUsed:          yield "    self.setTaperMode(curve, taperMode)"
        if s["Bevel Object"].isUsed:        yield "    curve.bevel_object = bevelObject"
        if s["Fill Caps"].isUsed:           yield "    curve.use_fill_caps = fillCaps"
        if s["Fill Mode"].isUsed:           yield "    self.setFillMode(curve, fillMode)"
        if s["Bevel Mode"].isUsed:          yield "    self.setBevelMode(curve, bevelMode)"

    def setSplines(self, object, splines):
        setSplinesOnBlenderObject(object, splines)

    def setTaperMode(self, curve, taperMode):
        if taperMode in ("OVERRIDE", "MULTIPLY", "ADD"):
            curve.taper_radius_mode = taperMode
        else:
            self.setErrorMessage("The taper mode is invalid. \n\nPossible values for 'Taper Mode' are: 'OVERRIDE', 'MULTIPLY', 'ADD'")

    def setFillMode(self, curve, fillMode):
        isCorrectFillMode = fillMode in ("FULL", "BACK", "FRONT", "HALF") if curve.dimensions == "3D" else fillMode in ("NONE", "BACK", "FRONT", "BOTH")
        if isCorrectFillMode:
            curve.fill_mode = fillMode
        else:
            self.setErrorMessage("The fill mode is invalid. \n\nPossible values for 'Fill Mode' are: \n3D Curve: 'FULL', 'HALF', 'BACK', 'FRONT' \n2D Curve: 'NONE', 'BACK', 'FRONT', 'BOTH'")

    def setBevelMode(self, curve, bevelMode):
        if bevelMode in ("ROUND", "OBJECT", "PROFILE"):
            curve.bevel_mode = bevelMode
        else:
            self.setErrorMessage("The bevel mode is invalid. \n\nPossible values for 'Bevel Mode' are: 'ROUND', 'OBJECT', 'PROFILE'")

    def getBakeCode(self):
        yield "if getattr(object, 'type', '') == 'CURVE':"
        yield "    curve = object.data"

        s = self.inputs
        if s["Bevel Depth"].isUsed:         yield "    curve.keyframe_insert('bevel_depth')"
        if s["Bevel Resolution"].isUsed:    yield "    curve.keyframe_insert('bevel_resolution')"
        if s["Bevel Start"].isUsed:         yield "    curve.keyframe_insert('bevel_factor_start')"
        if s["Bevel End"].isUsed:           yield "    curve.keyframe_insert('bevel_factor_end')"
        if s["Extrude"].isUsed:             yield "    curve.keyframe_insert('extrude')"
        if s["Offset"].isUsed:              yield "    curve.keyframe_insert('offset')"
        if s["Preview Resolution"].isUsed:  yield "    curve.keyframe_insert('resolution_u')"
